package user.details;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class validate {

		public  boolean validateemail(String email)
	    {
	        String front;
	        String end;
	        boolean check = false;
	        int index = 0;
	        if(email.contains("@"))
	        {
	            index = email.indexOf("@");
	            end = email.substring(index, email.length());
	            if(end.equals("@uncc.edu"))
	            {
	                front = email.substring(0, index);
	                if(front.matches("[a-zA-Z_0-9]+"))
	                    check = true;
	            }
	        }
	        return check;
	    }
		public boolean validateusername(String uname)
		{
			String uname1 =uname;
			try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	        }
	        catch(ClassNotFoundException e)
	        {
	            System.out.println(e.getMessage());
	        }
		 try
	        {
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/logindb","root","mylife@123");
	            Statement st = con.createStatement();
	            String q1 = "select username from userdata where username ='"+uname1+"'";
	            ResultSet rs = st.executeQuery(q1);
	            while(rs.next())
	            {
	            	return false;
	            }
	            st.close();
	            con.close();
	        }
		 catch(SQLException e)
	        {
	            System.out.println(e.getMessage());    
	        }
		 return true;
		}
}
