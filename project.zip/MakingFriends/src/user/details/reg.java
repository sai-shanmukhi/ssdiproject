package user.details;
import user.details.validate;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class reg
 */
@WebServlet("/reg")
public class reg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public reg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String name,email,dateofbirth,address,username,password,cpassword;
		String[] hobbies = new String[20];
		name = request.getParameter("name").toString();
		email = request.getParameter("email").toString();
		dateofbirth = request.getParameter("dob").toString();
		address = request.getParameter("address").toString();
		username = request.getParameter("username").toString();
		password = request.getParameter("password").toString();
		cpassword = request.getParameter("confirmpassword").toString();
		int sports,animation,music,books,videogames,travel,fitness,boardgames,food,tvmovies,youtubemedia,arts;
		if(request.getParameter("sports") == null)
		{
		   //handle unchecked case
		   sports = 0;
		}
		else
		{
		   //handle checked case
		   sports = 1;
		}
		if(request.getParameter("animation") == null)
		{
		   //handle unchecked case
		   animation = 0;
		}
		else
		{
		   //handle checked case
		   animation = 1;
		}
		if(request.getParameter("music") == null)
		{
		   //handle unchecked case
		   music = 0;
		}
		else
		{
		   //handle checked case
		   music = 1;
		}
		if(request.getParameter("books") == null)
		{
		   //handle unchecked case
		   books = 0;
		}
		else
		{
		   //handle checked case
		   books = 1;
		}
		if(request.getParameter("videogames") == null)
		{
		   //handle unchecked case
			videogames = 0;
		}
		else
		{
		   //handle checked case
			videogames = 1;
		}
		if(request.getParameter("travel") == null)
		{
		   //handle unchecked case
			travel = 0;
		}
		else
		{
		   //handle checked case
			travel = 1;
		}
		if(request.getParameter("fitness") == null)
		{
		   //handle unchecked case
			fitness = 0;
		}
		else
		{
		   //handle checked case
			fitness = 1;
		}
		if(request.getParameter("boardgames") == null)
		{
		   //handle unchecked case
			boardgames = 0;
		}
		else
		{
		   //handle checked case
			boardgames = 1;
		}
		if(request.getParameter("food") == null)
		{
		   //handle unchecked case
			food = 0;
		}
		else
		{
		   //handle checked case
			food = 1;
		}
		if(request.getParameter("tvmovies") == null)
		{
		   //handle unchecked case
			tvmovies = 0;
		}
		else
		{
		   //handle checked case
			tvmovies = 1;
		}
		if(request.getParameter("youtubemedia") == null)
		{
		   //handle unchecked case
			youtubemedia = 0;
		}
		else
		{
		   //handle checked case
			youtubemedia = 1;
		}
		if(request.getParameter("arts") == null)
		{
		   //handle unchecked case
			arts = 0;
		}
		else
		{
		   //handle checked case
			arts = 1;
		}
		String checkbox;
		if(request.getParameter("agree") != null)
		{
			//out.println("insert data");
		}
		else
		{
			out.println("please agree to conditions");
		}
		
		
		//System.out.println(Sports);
		System.out.println("Music is " + music);
		/*hobbies = request.getParameterValues("hobby");
		for(String s : hobbies)
			System.out.println(s);*/
			
		validate p = new validate();
		if(p.validateemail(email)==true)
		{
			System.out.println("yahooooooo    ");
		}
		boolean uservalid = p.validateusername(username);
		if(uservalid == false)
		{
			System.out.println("provide new username");
		}
		if(password.equals(cpassword))
		{
			System.out.println( "Password okay");
		}
		else
		{
			System.out.println(" Password mismatch.Re enter it ");
		}
			insert i = new insert();
				i.insertdb(name, email, dateofbirth, address, username, password, sports, animation, music, books, videogames, travel, fitness, boardgames, food, tvmovies, youtubemedia, arts);
		
		 
	}

}
