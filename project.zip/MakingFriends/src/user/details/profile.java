package user.details;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class profile
 */
@WebServlet("/profile")
public class profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("uname");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/profile.jsp");
	     dispatcher.forward(request, response);
		//String pname="";
		try
	    {
	        Class.forName("com.mysql.jdbc.Driver");
	    }
	    catch(ClassNotFoundException e)
	    {
	        System.out.println(e.getMessage());
	    }
	 try
	    {
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/logindb","root","mylife@123");
	        Statement st = con.createStatement();
	        Statement st1 = con.createStatement();
	        String q1 = "select name,email,dob,address from userdata where username ='"+uname+"'";
	        String q2 = "select concat_ws(\",\", (case when sports = 1 then 'sports' end),\n" +
                " (case when animation = 1 then 'animation' end),\n" +
                " (case when music = 1 then 'music' end),\n" +
                 " (case when books = 1 then 'books' end)," +
                 " (case when videogames = 1 then 'videogames' end)," +
                 " (case when travel = 1 then 'travel' end),"+
                 " (case when fitness = 1 then 'fitness' end),"+
                 " (case when boardgames = 1 then 'boardgames' end),"+
                 " (case when food = 1 then 'food' end),"+
                 " (case when tvmovies = 1 then 'tvmovies' end),"+
                 " (case when youtubemedia = 1 then 'youtubemedia' end),"+
                 " (case when arts = 1 then 'arts' end)"+
                ") from interest where username='"+uname+"' ";
            ResultSet rs = st.executeQuery(q1);
            ResultSet rs1 = st1.executeQuery(q2);
            while(rs1.next())
            {
            	String value =rs1.getString(1);
            	System.out.println(value);
            }
            
            while(rs.next())
            {
            	String name1 = rs.getString("name");
            	//System.out.println(name1);
            	session.setAttribute("pname",name1);
            	String email1 = rs.getString("email");
            	session.setAttribute("pemail",email1);
            	String dob1 = rs.getString("dob");
            	session.setAttribute("pdob",dob1);
            	String address1 = rs.getString("address");
            	session.setAttribute("paddress",address1);
            }
            while(rs1.next())
            {
            	
            }
            st.close();
	        con.close();       
	    }
	 	catch(SQLException e)
	    {
	        System.out.println(e.getMessage());    
	    }
	      
	      session.setAttribute("uname",uname);
		System.out.println("username in profile" + uname);
	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		HttpSession session1 = request.getSession();
		response.setContentType("text/html");
		String username = request.getParameter("username").toString();
		System.out.println(username);
		
	}

}
